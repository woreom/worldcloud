import twint

c = twint.Config()

c.Username = "woreom"
c.Limit = 3200
c.Store_txt = True
c.Output = "D:/M3/Projects/Python/Twitter/tweets/tweet.txt"

twint.run.Search(c)
